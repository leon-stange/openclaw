#!/usr/bin/env bash
set -euo pipefail

printf '\nOpenClaw WhatsApp Call Contact v0.1.2 - Ubuntu/Linux Setup\n\n'

for cmd in openclaw npm node meowcaller; do
  command -v "$cmd" >/dev/null 2>&1 || { echo "Fehler: $cmd wurde nicht gefunden." >&2; exit 1; }
done

read -r -p "Nummer A / Owner (Format +49...): " AUTHORIZED_CALLER
[[ "$AUTHORIZED_CALLER" =~ ^\+[1-9][0-9]{7,14}$ ]] || { echo "Fehler: Nummer A ist nicht im E.164-Format (+49...)." >&2; exit 1; }

read -r -p "Name des freigegebenen Kontakts [Annka]: " CONTACT_NAME
CONTACT_NAME="${CONTACT_NAME:-Annka}"

read -r -p "Nummer des Kontakts (Format +49...): " CONTACT_PHONE
[[ "$CONTACT_PHONE" =~ ^\+[1-9][0-9]{7,14}$ ]] || { echo "Fehler: Kontakt-Nummer ist nicht im E.164-Format (+49...)." >&2; exit 1; }

read -r -p "ElevenLabs Voice ID [QY3Oz57TOFa67IL9gWWV]: " VOICE_ID
VOICE_ID="${VOICE_ID:-QY3Oz57TOFa67IL9gWWV}"

STORE="$HOME/.openclaw/credentials/whatsapp-calls/default/wa-voip.db"
[[ -f "$STORE" ]] || { echo "Fehler: MeowCaller Store fehlt: $STORE" >&2; echo "Bitte zuerst MeowCaller fuer den default-Account pairen." >&2; exit 1; }

MEOWCALLER_PATH="$(command -v meowcaller)"
SCRIPT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
TMP_JSON="$(mktemp /tmp/openclaw-whatsapp-call-contact.XXXXXX.json)"
trap 'rm -f "$TMP_JSON"' EXIT

cd "$SCRIPT_DIR"

echo
echo "[1/6] Dependencies installieren..."
npm install

echo
echo "[2/6] Plugin bauen und validieren..."
npm run plugin:validate

echo
echo "[3/6] Plugin lokal installieren..."
openclaw plugins install -l "$SCRIPT_DIR" --no-enable --force

export AUTHORIZED_CALLER CONTACT_NAME CONTACT_PHONE VOICE_ID MEOWCALLER_PATH TMP_JSON
node <<'NODE'
const fs = require('node:fs');
const patch = {
  commands: {
    ownerAllowFrom: [`whatsapp:${process.env.AUTHORIZED_CALLER}`],
  },
  plugins: {
    entries: {
      "whatsapp-call-contact": {
        config: {
          authorizedCaller: process.env.AUTHORIZED_CALLER,
          contacts: [
            {
              name: process.env.CONTACT_NAME,
              phone: process.env.CONTACT_PHONE,
              aliases: [process.env.CONTACT_NAME],
            },
          ],
          voiceId: process.env.VOICE_ID,
          model: "eleven_multilingual_v2",
          accountId: "default",
          meowcallerPath: process.env.MEOWCALLER_PATH,
          maxMessageChars: 450,
          maxCallsPer10Minutes: 5,
        },
      },
    },
  },
};
fs.writeFileSync(process.env.TMP_JSON, JSON.stringify(patch, null, 2) + "\n", { mode: 0o600 });
NODE

echo
echo "[4/6] Konfiguration pruefen und anwenden..."
openclaw config patch --file "$TMP_JSON" --dry-run
openclaw config patch --file "$TMP_JSON"

echo
echo "[5/6] Plugin aktivieren..."
openclaw plugins enable whatsapp-call-contact

echo
echo "[6/6] Gateway neu starten und Runtime pruefen..."
openclaw gateway restart
sleep 5
openclaw plugins inspect whatsapp-call-contact --runtime

echo
echo "Fertig."
echo "Wichtig: commands.ownerAllowFrom wurde auf Nummer A gesetzt."
printf 'Test: Ruf %s an und sag: "Hallo, das ist ein Test von Jarvis."\n' "$CONTACT_NAME"
