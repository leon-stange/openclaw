# OpenClaw WhatsApp Call Contact

Ein kleines OpenClaw-Tool-Plugin fuer dein Jarvis-Setup.

Es ermoeglicht genau diesen Ablauf:

- Nummer A schreibt Jarvis per WhatsApp.
- Jarvis darf ausschliesslich vorher freigegebene Kontakte aus der Plugin-Konfiguration auswaehlen.
- ElevenLabs erzeugt die Sprachdatei.
- MeowCaller ruft die hinterlegte WhatsApp-Nummer an, spielt die Nachricht ab und legt auf.

## Sicherheitsregeln

- Das Tool ist nur in einem eingehenden WhatsApp-Turn verfuegbar.
- Der vertrauenswuerdige `requesterSenderId` von OpenClaw muss exakt `authorizedCaller` entsprechen.
- Das Modell kann **keine Telefonnummer als Tool-Parameter** uebergeben.
- Zielnummern kommen ausschliesslich aus `plugins.entries.whatsapp-call-contact.config.contacts`.
- Standard-Limit: 5 Anrufe in 10 Minuten.
- Standard-Maximum: 450 Zeichen pro gesprochener Nachricht.
- Temporäre MP3-Dateien werden nach dem Anruf geloescht.
- Der ElevenLabs-Key bleibt in `ELEVENLABS_API_KEY`/`XI_API_KEY` und wird nicht in der Plugin-Konfiguration gespeichert.

## Voraussetzungen

- OpenClaw 2026.9.8 oder neuer
- Node.js passend zu OpenClaw
- funktionierende WhatsApp-Verbindung in OpenClaw
- MeowCaller im PATH
- gepairter MeowCaller-Store unter:
  `~/.openclaw/credentials/whatsapp-calls/default/wa-voip.db`
- `ELEVENLABS_API_KEY` oder `XI_API_KEY` im Gateway-Prozess

## Installation unter Windows

ZIP entpacken, PowerShell im entpackten Ordner oeffnen und ausfuehren:

```powershell
Set-ExecutionPolicy -Scope Process Bypass
.\install.ps1
```

Das Setup fragt nach:

- Nummer A (autorisierter WhatsApp-Absender)
- Kontaktname fuer Nummer B
- Nummer B
- ElevenLabs Voice ID (deine aktuelle Voice ID ist als Standard vorbelegt)

## Test

Von Nummer A an Jarvis schreiben:

```text
Ruf Nummer B an und sag: "Hallo, das ist ein Test von Jarvis."
```

Oder mit dem im Setup vergebenen Kontaktnamen.

## Weitere Kontakte hinzufuegen

Bearbeite spaeter die Plugin-Konfiguration unter:

```text
plugins.entries.whatsapp-call-contact.config.contacts
```

Beispiel:

```json5
[
  { name: "Nummer B", phone: "+49123456789", aliases: ["B"] },
  { name: "Mutter", phone: "+49987654321", aliases: ["Mama"] }
]
```

Danach Plugin/Gateway neu laden.

## Diagnose

```powershell
openclaw.cmd plugins inspect whatsapp-call-contact --runtime
openclaw.cmd gateway status --deep
openclaw.cmd channels status --channel whatsapp --probe
openclaw.cmd logs --follow
```

Wenn das Tool im Agenten nicht sichtbar ist, pruefen:

```powershell
openclaw.cmd plugins validate --root . --entry ./dist/index.js
openclaw.cmd plugins reload whatsapp-call-contact
```


## 0.1.1

Authorization now uses OpenClaw `senderIsOwner` instead of comparing the raw WhatsApp requester id to an E.164 number. This fixes WhatsApp LID senders while keeping the tool owner-only. Ensure Number A is present in `commands.ownerAllowFrom`.

## Ubuntu/Linux v0.1.2

Diese Variante ist fuer Ubuntu/Linux vorbereitet und enthaelt `install.sh` statt des Windows-PowerShell-Installers.

Wichtige Korrekturen:
- Owner-Pruefung erfolgt ueber `toolContext.senderIsOwner`, damit WhatsApp-LID-Absender funktionieren.
- `commands.ownerAllowFrom` wird vom Installer gesetzt.
- MeowCaller wird ueber den tatsaechlichen Linux-Pfad aus `command -v meowcaller` eingetragen.
- Der MeowCaller-Store wird unter `$HOME/.openclaw/credentials/whatsapp-calls/default/wa-voip.db` erwartet.
- Installation nutzt `openclaw plugins install -l ... --no-enable --force`.

Installation:

```bash
chmod +x install.sh
./install.sh
```

Vorher muessen OpenClaw, Node/npm, MeowCaller, WhatsApp und der ElevenLabs-Key fuer den Gateway eingerichtet sein.
